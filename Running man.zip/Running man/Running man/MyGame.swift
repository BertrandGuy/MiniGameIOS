//
//  MyGame.swift
//  Running man
//
//  Created by GUY Bertrand on 19/06/2018.
//  Copyright © 2018 GUY Bertrand. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
