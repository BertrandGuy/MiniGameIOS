//
//  MainGame.swift
//  Running man
//
//  Created by GUY Bertrand on 19/06/2018.
//  Copyright © 2018 GUY Bertrand. All rights reserved.
//

import UIKit

class MainGame: SKScene {

}
